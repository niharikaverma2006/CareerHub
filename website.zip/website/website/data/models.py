from django.db import models

class Contact(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    subject = models.CharField(max_length=200)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    
class Jobs(models.Model):
    name = models.CharField(max_length=100)
    jobid = models.EmailField()
    role = models.CharField(max_length=200)
    salary = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

class create_job(models.Model):
    role = models.CharField(max_length=100)
    job_id = models.IntegerField()
    company = models.CharField(max_length=200)
    salary = models.IntegerField()
    job_type = models.CharField(max_length=100)
    description= models.CharField()
    location=models.CharField()
    requirements = models.CharField(max_length=200)
    experience= models.IntegerField()
    created_at = models.DateTimeField(auto_now_add=True)

class apply_now(models.Model):

    name = models.CharField(max_length=100)

    email = models.EmailField()

    phone = models.CharField(max_length=15)

    job_id = models.ForeignKey(create_job,on_delete=models.CASCADE)
  

    job_title = models.CharField(max_length=100)

    resume = models.FileField(upload_to='resumes/',default=None)

    # cover_letter = models.TextField(default=None)

    applied_at = models.DateTimeField(auto_now_add=True)


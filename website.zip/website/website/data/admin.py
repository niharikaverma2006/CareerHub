from django.contrib import admin
from .models import apply_now
admin.site.register(apply_now)
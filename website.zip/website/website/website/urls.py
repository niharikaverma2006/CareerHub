"""
URL configuration for website project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from  . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.index,name='home'),
    path('about/',views.about),
    path('services/',views.services),
    path('contact/', views.contact),
    path('login/',views.login),
    path('register/',views.register),
    path('Jobs/',views.Jobs,name='jobs'),
    path('create_job/',views.create_job,name='create_job'),
    path('showcontact/',views.showcontact),
    path('apply_now/',views.apply_now),
]


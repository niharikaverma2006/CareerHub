from django.shortcuts import render
from django.contrib.auth.models import User    
from django.contrib.auth import authenticate     
from data.models import Contact as cont,Jobs as job,create_job as newjob,apply_now as apply



def index(request):
    return render(request ,"home.html")
def  about(request):
    return render(request ,"about.html" )
def services(request): 
    return render(request ,'services.html')
def contact(request):
   return render(request,'contact.html')
def login(request):
    return render(request,'login.html')
def register(request):
    return render(request,'register.html')
def showcontact(request):
    data=cont.objects.filter().all()
    print(data)
    return render(request,'showcontact.html',{"data":data})


def contact (request):
    if request.method=="POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        subject=request.POST.get('subject')
        message=request.POST.get('message')
        fd=cont.objects.create(name=name,email=email,subject=subject,message=message)


        print(name,email,subject,message)
    return render(request,'contact.html')

def Jobs(request):
    data=newjob.objects.filter().all()
    print(data)
      
 
    return render(request,'Jobs.html',{"data":data})

def login(request):
    if request.method=="POST":
        name=request.POST.get('name')
        password=request.POST.get('password')

        user= authenticate(username=name,password=password)
        if user is None:
            print('login id does not exist')
        else:
     
            print('login succesfully')    

        print(name,password)
    return render(request,'login.html')    

def register(request):
    if request.method=="POST":
        name=request.POST.get('name')
        password=request.POST.get('password')
        email=request.POST.get('email')
        re_enterpassword=request.POST.get('re_enter password')
        if password!=re_enterpassword:
            print("password does not match")

        user =User.objects.create_user(username=name,email=email,password=password)   
        print ('created')     

        print(name,password,email,re_enterpassword)
    return render(request,'register.html')    

def create_job(request):
    if request.method == "POST":

        job_id = request.POST.get("job_id")

        role = request.POST.get("role")

        company = request.POST.get("company")

        location = request.POST.get("location")

        salary = request.POST.get("salary")

        job_type = request.POST.get("job_type")

        description = request.POST.get("description")

        requirements = request.POST.get("requirements")

        experience = request.POST.get("experience")
        fd=newjob.objects.create(job_id=job_id,role=role,company=company,location=location,salary=salary,job_type=job_type,description=description,requirements=requirements,experience=experience)
        fd.save()
       

   
    return render(request,"create_job.html")    

def apply_now(request):
    job_id=request.GET.get("jobid")
    idd=newjob.objects.get(id=job_id)
    print(idd)
    if request.method=="POST":
        name=request.POST.get("name")
        email=request.POST.get("email")
        phone=request.POST.get("phone")
      
        job_title=request.POST.get("job_title")
        cover_letter=request.POST.get("cover_letter")
        resume=request.FILES.get("resume")

        fd=apply.objects.create(name=name,email=email,phone=phone,job_id=idd,job_title=job_title,resume=resume)
        
        print(name and email and phone and job_id and job_title and resume )

        print(request,"your application has been submitted successfully!")
    return render(request,"apply_now.html")    
        
        
        

        



        


